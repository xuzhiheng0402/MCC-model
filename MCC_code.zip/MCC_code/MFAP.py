import torch
import torch.nn as nn
import torch.nn.functional as F

class MFAP(nn.Module):


    def __init__(self, kernel_size: int = 7):
        super().__init__()
        self.kernel_size = kernel_size
        self.pad = kernel_size // 2

        # ✅ 不在 __init__ 创建 Conv
        self.act = nn.ReLU(inplace=True)
        self.sigmoid = nn.Sigmoid()

    def _get_hw_convs(self, c: int, device):
        """懒加载 H/W 分支卷积"""
        if (
            not hasattr(self, "hw_conv1") or
            self.hw_conv1.in_channels != c
        ):
            hidden = max(1, c // 16)
            self.hw_conv1 = nn.Conv2d(c, hidden, 1, bias=False).to(device)
            self.hw_conv2 = nn.Conv2d(hidden, c, 1, bias=False).to(device)

        return self.hw_conv1, self.hw_conv2

    def _get_spatial_conv(self, device):
        """懒加载空间分支卷积"""
        if not hasattr(self, "spatial_conv"):
            self.spatial_conv = nn.Conv2d(
                1, 1,
                kernel_size=self.kernel_size,
                padding=self.pad,
                bias=False
            ).to(device)
        return self.spatial_conv

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, h, w = x.shape
        device = x.device

        hw_conv1, hw_conv2 = self._get_hw_convs(c, device)
        spatial_conv = self._get_spatial_conv(device)

        # ---------- H attention ----------
        fh = x.mean(2, keepdim=True) + x.amax(2, keepdim=True)
        mh = hw_conv2(self.act(hw_conv1(fh)))
        mh = self.sigmoid(mh)

        # ---------- W attention ----------
        fw = x.mean(3, keepdim=True) + x.amax(3, keepdim=True)
        mw = hw_conv2(self.act(hw_conv1(fw)))
        mw = self.sigmoid(mw)

        # ---------- Spatial attention ----------
        fs = x.mean(1, keepdim=True) + x.amax(1, keepdim=True)
        ms = spatial_conv(fs)
        ms = self.sigmoid(ms)

        return x * mh * mw * ms